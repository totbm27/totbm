package org.jinstagram.http;

/**
 * An enumeration containing the most common HTTP Verbs.
 */
public enum Verbs {
	GET, POST, PUT, DELETE
}
